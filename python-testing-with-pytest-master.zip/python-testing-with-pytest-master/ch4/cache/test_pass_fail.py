def test_this_passes():
    assert 1 == 1


def test_this_fails():
    assert 1 == 2
