from setuptools import setup

setup(name="some_module", py_modules=["some_module"])
