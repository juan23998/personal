====================================================
some_package: Demonstrate packaging and distribution
====================================================

``some_package`` is the Python package to demonstrate how easy it is to create installable, maintainable, shareable packages and distributions.

It contains one function, ``some_func()``.

  >>> import some_package
  >>> some_package.some_func()
  42

That's it, really