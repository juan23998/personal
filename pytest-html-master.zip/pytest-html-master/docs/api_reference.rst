API Reference
-------------

This is a reference to the plugin API.

Hooks
~~~~~

This plugin exposes the following hooks:

.. automodule:: pytest_html.hooks
   :members:
