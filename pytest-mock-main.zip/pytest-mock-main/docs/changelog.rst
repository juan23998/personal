=========
Changelog
=========

:hide-toc:

.. include:: ../CHANGELOG.rst
